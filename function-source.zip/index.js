const functions = require('@google-cloud/functions-framework');
const http = require('node:http');

let counter = 0;
let instanceID = "";
let region = "";
// Register an HTTP function with the Functions Framework that will be executed
// when you make an HTTP request to the deployed function's endpoint.
functions.http('helloHttp', async (req, res) => {
  console.log("Starting ...");
  counter++;
  console.log(`This container has been invoked: ${counter} times`)
  
  getMetadata("/computeMetadata/v1/instance/id");
  getMetadata("/computeMetadata/v1/instance/region");

  // Sleep for 3 seconds
  await sleep(3000);
  console.log("Ended!");

  let response = {
    instanceID: instanceID,
    counter: counter,
    region: region
  }
  
  //res.status(200).send(`${instanceID} served this request. \n This container has been invoked: ${counter} times`);
  res.status(200).json(response);
});


function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}


function getMetadata(pathUrl){
  const options = {
    hostname: 'metadata.google.internal',
    path: pathUrl,
    method: 'GET',
    headers: {
      'Metadata-Flavor': 'Google'
    }
  };

  const instanceReq = http.request(options, (res) => {
    let data = '';
  
    res.on('data', (chunk) => {
      data += chunk;
    });
  
    res.on('end', () => {
      if(pathUrl == "/computeMetadata/v1/instance/id"){
        instanceID = data;
        console.log(`The instance ID is: ${data}`);
      } 
      else if(pathUrl == "/computeMetadata/v1/instance/region"){
        region = data;
        console.log(`The region is: ${data}`);
      }
      else{
        console.error("Invalid path");
      }
      
    });
  });
  
  instanceReq.on('error', (error) => {
    console.error(error);
  });
  
  instanceReq.end();
}

